# M2-class-exercises
repository for m2 muscle builder activities
## I am a student in Yeshiva University's Data Analytics and Visualization program. This repository is for weekly class activities and assignments to practice, learn and demonstrate understanding of Python, Jupyter Notebook, and coding within these and other platforms
### Kristin Medlin, graduate student, Yeshiva University
